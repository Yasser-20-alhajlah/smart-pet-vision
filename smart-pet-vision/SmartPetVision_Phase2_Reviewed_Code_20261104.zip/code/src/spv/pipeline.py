"""M8 - the integrated system: detect -> crop -> classify -> segment -> verdict."""
from __future__ import annotations

import base64
import io
import time
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageOps

from .constants import CLASSES
from .common import load_json, save_json
from .instance_alignment import best_mask_index
from .multi_animal_review import (ReviewProposal, additional_animal_cues,
                                  map_tile_boxes, review_tiles, validate_boxes)

REASONS = {
    "invalid_segmentation": "The segmentation output is invalid; staff review required.",
    "no_animal": "No cat or dog was detected.",
    "multiple_animals": "More than one animal was detected.",
    "low_confidence": "The species prediction is below the verification threshold.",
    "disagreement": "The detector and the classifier disagree on the species.",
    "animal_too_small": "The animal covers too little of the frame; retake the photo.",
    "segmentation_unmatched": "The segmenter could not match a reliable animal mask to the selected detection.",
    "segmentation_disagreement": "The segmenter and the selected detector disagree on the animal species.",
    "secondary_animal_candidate": "A second, lower-threshold pass found an additional or ambiguous animal candidate; staff review required.",
    "secondary_review_failed": "The additional-animal safety check could not be completed; staff review required.",
}


class InvalidModelOutput(ValueError):
    """Model output cannot safely support a decision."""


def crop_coordinates(box, width, height):
    """Enclose a valid subpixel box without producing an empty crop."""
    x1, y1, x2, y2 = box
    return (max(0, int(np.floor(x1))), max(0, int(np.floor(y1))),
            min(width, int(np.ceil(x2))), min(height, int(np.ceil(y2))))


def validate_detections(boxes, classes, scores, width, height):
    boxes, classes, scores = np.asarray(boxes), np.asarray(classes), np.asarray(scores)
    if (boxes.ndim != 2 or boxes.shape[1:] != (4,) or classes.shape != (len(boxes),)
            or scores.shape != (len(boxes),)):
        raise InvalidModelOutput("Detection dimensions do not align.")
    if (not np.isfinite(boxes).all() or not np.isfinite(classes).all()
            or not np.isfinite(scores).all() or not np.isin(classes, range(len(CLASSES))).all()
            or ((scores < 0) | (scores > 1)).any()
            or not (boxes[:, 2:] > boxes[:, :2]).all()
            or (boxes < 0).any() or (boxes[:, [0, 2]] > width).any()
            or (boxes[:, [1, 3]] > height).any()):
        raise InvalidModelOutput("Detection values are invalid.")
    return boxes.astype(float), classes.astype(int), scores.astype(float)


@dataclass
class SegmentationEvidence:
    """One selected mask and independent animal evidence from the segmenter.

    Iteration preserves the public (mask, matched) unpacking contract.
    """
    mask: np.ndarray
    matched: bool
    animal_count: int
    selected_species: str | None = None

    def __iter__(self):
        yield self.mask
        yield self.matched


@dataclass
class Manifest:
    """Everything the service needs, written once by notebook 05."""
    detector: str
    segmenter: str
    classifier: str
    classifier_kind: str
    temperature: float
    detector_conf: float
    detector_iou: float
    verify_threshold: float
    min_mask_fraction: float
    image_size: int = 224
    imgsz: int = 640
    segmenter_conf: float = 0.25
    segmenter_iou: float = 0.70
    mask_match_iou: float = 0.10
    # Opt-in candidate only. Historical manifests and weights remain unchanged.
    review_mode: str = "off"  # off | audit | enforce
    review_conf: float = 0.10
    review_imgsz: int = 960
    review_match_iou: float = 0.55
    review_include_segmenter: bool = True
    review_tiles_enabled: bool = False
    review_tiles_conf: float = 0.10

    @classmethod
    def load(cls, path: str | Path, project_root: str | Path | None = None) -> "Manifest":
        path = Path(path).expanduser().resolve()
        data = load_json(path)
        root = Path(project_root).resolve() if project_root else (
            path.parent.parent if path.parent.name == "runs" else path.parent)
        for key in ("detector", "segmenter", "classifier"):
            value = Path(data[key]).expanduser()
            data[key] = str(value if value.is_absolute() else (root / value).resolve())
        manifest = cls(**data)
        if not np.isfinite(manifest.temperature) or manifest.temperature <= 0:
            raise ValueError("Manifest temperature must be finite and positive.")
        for name in ("detector_conf", "detector_iou", "verify_threshold", "min_mask_fraction",
                     "segmenter_conf", "segmenter_iou", "mask_match_iou"):
            value = getattr(manifest, name)
            if not np.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"Manifest {name} must be between zero and one.")
        if manifest.mask_match_iou == 0:
            raise ValueError("Manifest mask_match_iou must be positive.")
        for name in ("image_size", "imgsz"):
            value = getattr(manifest, name)
            if isinstance(value, bool) or not isinstance(value, int) or value < 1:
                raise ValueError(f"Manifest {name} must be a positive integer.")
        if manifest.classifier_kind not in {"scratch", "frozen", "finetune"}:
            raise ValueError("Manifest classifier_kind is not supported.")
        if manifest.review_mode not in {'off', 'audit', 'enforce'}:
            raise ValueError('Manifest review_mode must be off, audit or enforce.')
        if type(manifest.review_include_segmenter) is not bool or type(manifest.review_tiles_enabled) is not bool:
            raise ValueError('Review switches must be booleans.')
        for key in ('review_conf', 'review_match_iou', 'review_tiles_conf'):
            value = getattr(manifest, key)
            if not np.isfinite(value) or not 0 < value <= 1:
                raise ValueError(f'{key} must be finite and in (0,1].')
        if manifest.review_conf > manifest.detector_conf:
            raise ValueError('Secondary review confidence must be <= primary confidence.')
        if type(manifest.review_imgsz) is not int or manifest.review_imgsz < manifest.imgsz:
            raise ValueError('Secondary review resolution must be >= primary image size.')
        return manifest

    def save(self, path: str | Path) -> None:
        save_json(self.__dict__, path)


class PetPipeline:
    def __init__(self, m: Manifest, cfg: dict | None = None):
        from ultralytics import YOLO
        from .classify import load_model, transforms

        self.m = m
        self.detector = YOLO(m.detector, task="detect")
        self.segmenter = YOLO(m.segmenter, task="segment")
        cfg = cfg or {"classification": {"backbone": "resnet50", "pretrained": False}}
        self.classifier = load_model(m.classifier_kind, cfg, Path(m.classifier))
        self.tf = transforms(m.image_size, train=False)
        self.device = next(self.classifier.parameters()).device

    # ---------------------------------------------------------- stages
    def detect(self, im: Image.Image):
        r = self.detector.predict(im, conf=self.m.detector_conf, iou=self.m.detector_iou,
                                  imgsz=self.m.imgsz, rect=False, verbose=False)[0]
        return (r.boxes.xyxy.cpu().numpy(), r.boxes.cls.cpu().numpy().astype(int),
                r.boxes.conf.cpu().numpy())

    def classify(self, crop: Image.Image) -> np.ndarray:
        import torch
        from .classify import softmax

        x = self.tf(crop).unsqueeze(0).to(self.device)
        with torch.no_grad():
            return softmax(self.classifier(x).float().cpu().numpy(), self.m.temperature)[0]

    def segment(self, im: Image.Image, selected_box: np.ndarray | None = None,
                selected_class: int | None = None) -> SegmentationEvidence:
        """Match one segmenter instance to the classified detection (never union all masks).

        Preserve the segmenter's independent animal count: selecting a single
        mask must not discard evidence of another animal missed by the detector.
        """
        r = self.segmenter.predict(im, imgsz=self.m.imgsz, retina_masks=True,
                                   conf=self.m.segmenter_conf, iou=self.m.segmenter_iou,
                                   rect=False, verbose=False)[0]
        h, w = im.height, im.width
        empty = np.zeros((h, w), dtype=bool)
        if r.boxes is None:
            return SegmentationEvidence(empty, False, 0)
        boxes = r.boxes.xyxy.cpu().numpy()
        classes = r.boxes.cls.cpu().numpy().astype(int)
        if boxes.ndim != 2 or boxes.shape[1:] != (4,) or len(classes) != len(boxes):
            return SegmentationEvidence(empty, False, 0)
        valid = (np.isfinite(boxes).all(axis=1)
                 & (boxes[:, 2:] > boxes[:, :2]).all(axis=1)
                 & np.isin(classes, range(len(CLASSES))))
        count = int(valid.sum())
        if tuple(r.orig_shape) != (h, w) or selected_box is None or r.masks is None or r.boxes is None:
            return SegmentationEvidence(empty, False, count)
        masks = r.masks.data.cpu().numpy()
        if not np.isfinite(masks).all() or not np.isin(masks, [0, 1]).all():
            return SegmentationEvidence(empty, False, count)
        masks = masks.astype(bool)
        if len(masks) != len(boxes) or not valid.all():
            return SegmentationEvidence(empty, False, count)
        index = best_mask_index(boxes, selected_box, classes, selected_class,
                                min_iou=self.m.mask_match_iou)
        if index is None or index >= len(masks):
            return SegmentationEvidence(empty, False, count)
        mask = masks[index]
        # Don't silently remap pixel coordinates if the runtime changes mask size.
        if mask.shape != (h, w):
            return SegmentationEvidence(empty, False, count)
        return SegmentationEvidence(mask, True, count, CLASSES[int(classes[index])])

    # --------------------------------------- opt-in multi-animal safety probe
    def audit_additional_animals(self, im: Image.Image, primary_boxes: np.ndarray) -> dict:
        """Reconsider a *single-animal* image with high-res and optional tiled views.

        This function only proposes reasons for human referral, never asserts
        the exact number of animals. The original detector and weights are reused.
        """
        image_size = (im.width, im.height)
        proposals = []
        settings = {'imgsz': int(self.m.review_imgsz), 'conf': float(self.m.review_conf),
                    'iou': float(self.m.detector_iou), 'rect': False, 'verbose': False}
        def collect(model, source, source_image, *, tile=None, override=None):
            options = dict(settings)
            if override:
                options.update(override)
            result_list = model.predict(source_image, **options)
            if len(result_list) != 1:
                raise ValueError('Secondary model did not return exactly one image result.')
            result = result_list[0]
            expected_shape = (source_image.height, source_image.width)
            if result.boxes is None or tuple(result.orig_shape) != (expected_shape[0], expected_shape[1]):
                raise ValueError('Secondary model has missing/misaligned boxes.')
            boxes = result.boxes.xyxy.cpu().numpy()
            scores = result.boxes.conf.cpu().numpy()
            if tile is not None:
                boxes = map_tile_boxes(boxes, tile, image_size)
            else:
                validate_boxes(boxes, scores, bounds=image_size)
            proposals.append(ReviewProposal(source, boxes, scores))

        collect(self.detector, 'detector_high_resolution', im)
        if self.m.review_include_segmenter:
            collect(self.segmenter, 'segmenter_high_resolution', im)
        if self.m.review_tiles_enabled:
            for idx, tile in enumerate(review_tiles(im.width, im.height)):
                crop = im.crop(tile)
                collect(self.detector, f'detector_tile_{idx}', crop, tile=tile,
                        override={'imgsz': int(self.m.imgsz), 'conf': float(self.m.review_tiles_conf)})
        cues = additional_animal_cues(primary_boxes, proposals,
                    confidence_floor=min(self.m.review_conf, self.m.review_tiles_conf)
                                     if self.m.review_tiles_enabled else self.m.review_conf,
                    same_instance_iou=self.m.review_match_iou, image_size=image_size)
        return {'status': 'evaluated', 'candidate_count': len(cues),
                'candidates': cues, 'pass_count': len(proposals),
                'settings': {'confidence': self.m.review_conf, 'imgsz': self.m.review_imgsz,
                             'match_iou': self.m.review_match_iou,
                             'include_segmenter': self.m.review_include_segmenter,
                             'tiles_enabled': self.m.review_tiles_enabled}}

    # ------------------------------------------------------------ main
    def analyze(self, im: Image.Image, with_images: bool = True) -> dict:
        started = time.perf_counter()
        im = ImageOps.exif_transpose(im).convert("RGB")
        timings, t = {}, time.perf_counter()

        boxes, classes, confs = self.detect(im)
        boxes, classes, confs = validate_detections(boxes, classes, confs, im.width, im.height)
        timings["detect_ms"] = (time.perf_counter() - t) * 1e3
        reasons = []
        if len(boxes) == 0:
            reasons.append("no_animal")
            box = np.array([0, 0, im.width, im.height], float)
            det_species = None
            det_class = None
        else:
            if len(boxes) > 1:
                reasons.append("multiple_animals")
            k = int(confs.argmax())
            box, det_species = boxes[k], CLASSES[classes[k]]
            det_class = int(classes[k])

        t = time.perf_counter()
        crop = im.crop(crop_coordinates(box, im.width, im.height))
        probs = np.asarray(self.classify(crop))
        if (probs.shape != (len(CLASSES),) or not np.isfinite(probs).all()
                or (probs < 0).any() or (probs > 1).any()
                or not np.isclose(probs.sum(), 1.0, atol=1e-5, rtol=1e-5)):
            raise InvalidModelOutput("Classifier probabilities are invalid.")
        species = CLASSES[int(probs.argmax())]
        timings["classify_ms"] = (time.perf_counter() - t) * 1e3
        if probs.max() < self.m.verify_threshold:
            reasons.append("low_confidence")
        if det_species and det_species != species:
            reasons.append("disagreement")

        t = time.perf_counter()
        segmentation = self.segment(im,
                                         selected_box=box if det_class is not None else None,
                                         selected_class=det_class)
        mask, seg_matched = segmentation
        mask = np.asarray(mask)
        if (mask.shape != (im.height, im.width) or not np.isfinite(mask).all()
                or not np.isin(mask, [0, 1]).all()):
            mask = np.zeros((im.height, im.width), dtype=bool)
            seg_matched = False
            reasons.append("invalid_segmentation")
        mask = mask.astype(bool)
        segmentation_count = getattr(segmentation, "animal_count", None)
        segmentation_species = getattr(segmentation, "selected_species", None)
        if segmentation_count is not None and segmentation_count > 1 and "multiple_animals" not in reasons:
            reasons.append("multiple_animals")
        if seg_matched and segmentation_species is not None and segmentation_species != det_species:
            reasons.append("segmentation_disagreement")
        if "no_animal" not in reasons and not seg_matched:
            reasons.append("segmentation_unmatched")
        timings["segment_ms"] = (time.perf_counter() - t) * 1e3
        fraction = float(mask.mean())
        if "no_animal" not in reasons and fraction < self.m.min_mask_fraction:
            reasons.append("animal_too_small")
        # Run only on images that would otherwise be provisionally READY.
        # Any probe failure is fail-closed in 'enforce', and auditable in 'audit'.
        review = {'status': 'disabled', 'candidate_count': 0, 'candidates': []}
        mode = getattr(self.m, 'review_mode', 'off')
        if mode in {'audit', 'enforce'}:
            if reasons or len(boxes) != 1:
                review = {'status': 'skipped_already_referred',
                          'candidate_count': 0, 'candidates': []}
            else:
                review_started = time.perf_counter()
                try:
                    review = self.audit_additional_animals(im, boxes)
                    if mode == 'enforce' and review['candidate_count'] > 0:
                        reasons.append('secondary_animal_candidate')
                except Exception as exc:
                    review = {'status': 'failed', 'candidate_count': None, 'candidates': [],
                              'error_type': type(exc).__name__}
                    if mode == 'enforce':
                        reasons.append('secondary_review_failed')
                timings['secondary_review_ms'] = (time.perf_counter()-review_started)*1e3
        timings["stages_sum_ms"] = sum(timings.values())

        result = {
            "verdict": "ready" if not reasons else "refer_to_staff",
            # A readiness candidate is NOT permission to publish.
            # The current detector missed animals in multi-animal external photos.
            # Downstream clients must not bypass explicit staff approval.
            "staff_approval_required": True,
            "automatic_publication_allowed": False,
            "reasons": [{"code": r, "message": REASONS[r]} for r in reasons],
            "species": species,
            "confidence": float(probs.max()),
            "probabilities": {c: float(p) for c, p in zip(CLASSES, probs)},
            "detections": [{"box_xyxy": [float(v) for v in b], "species": CLASSES[c],
                            "confidence": float(s)} for b, c, s in zip(boxes, classes, confs)],
            "mask_fraction": fraction,
            "segmentation_matched": bool(seg_matched),
            "segmentation_animal_count": segmentation_count,
            "segmentation_species": segmentation_species,
            "secondary_review": review,
            "image_size": [im.width, im.height],
            "timings": timings,
        }
        if with_images:
            result["annotated_png"] = _b64(annotate(im, result, mask))
            result["cutout_png"] = _b64(cutout(im, mask, box))
            result["mask_png"] = _b64(Image.fromarray((mask * 255).astype(np.uint8)))
        # Direct wall time includes preprocessing, decisions and optional image encoding.
        timings["total_ms"] = (time.perf_counter() - started) * 1e3
        return result


def annotate(im: Image.Image, res: dict, mask: np.ndarray) -> Image.Image:
    arr = np.array(im).astype(float)
    arr[mask] = 0.6 * arr[mask] + 0.4 * np.array([0, 160, 255])
    out = Image.fromarray(arr.astype(np.uint8))
    d = ImageDraw.Draw(out)
    w = max(2, im.width // 200)
    for det in res["detections"]:
        d.rectangle(det["box_xyxy"], outline=(255, 80, 0), width=w)
    colour = (0, 150, 0) if res["verdict"] == "ready" else (200, 0, 0)
    d.rectangle([0, 0, im.width, 22], fill=(255, 255, 255))
    d.text((4, 4), f"{res['verdict']} | {res['species']} {res['confidence']:.2f} | "
                   f"mask {res['mask_fraction']:.0%}", fill=colour)
    return out


def cutout(im: Image.Image, mask: np.ndarray, box: np.ndarray) -> Image.Image:
    rgba = im.convert("RGBA")
    rgba.putalpha(Image.fromarray((mask * 255).astype(np.uint8)))
    return rgba.crop(crop_coordinates(box, im.width, im.height))


def _b64(im: Image.Image) -> str:
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()
