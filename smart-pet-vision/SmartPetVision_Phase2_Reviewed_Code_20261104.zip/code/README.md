# Reviewed executable source

Restore the authorised report/evidence and report/figures directories from the private submission source before running the complete evidence-consistency suite. Restore the three trained weights at runs/manifest.json paths.

Run from code/: PYTHONPATH=src:. SPV_MANIFEST=runs/manifest.json python -m uvicorn spv.serve:app --host 127.0.0.1 --port 8000 --workers 1

The package excludes report source, experiment evidence, photographs, weights and personal identifiers. Runtime source matches the reviewed local CPU snapshot.
