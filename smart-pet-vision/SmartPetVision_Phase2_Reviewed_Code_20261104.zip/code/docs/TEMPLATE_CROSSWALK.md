# Phase 2 instructor template crosswalk

Team and system: Section 1, operational contracts and RUN_SERVICE.md. M4 conversion/splits: Section 2; exact box repair ledger remains open. M4 and M5 original 40-epoch curves and resolved training options: recovered from unchanged checkpoints, in the review addendum; exact retained epoch remains unverified. M5 ground truth and reference: Section 3; per-species scores added; before-fine-tuning validation baseline and threshold-selection evidence open. M8: Section 4 and current review addendum; direct timing and stage percentiles added; network HTTP and current T4 verification open. Phase 1 improvement plan: current addendum. Open-world: omitted for team of 4. Every unresolved experiment must remain unresolved rather than reusing test to choose settings.


تحديث 2 نوفمبر 2026: أكد المستخدم أن الفريق أربعة أعضاء؛ أعيد تصنيف أحجام Oxford حسب نسبة الإطار من metadata المحفوظة: 0 صغير، 4 متوسط، 1102 كبير. يقابل ذلك recall 4/4 و1057/1102 باستعمال سجل FN المحفوظ. تعارض إعداد AdamW في الأوزان مع SGD في تقرير الفريق ما زال يحتاج ربط W&B ببصمة كل وزن.
