# Candidate service instructions and source boundary

The following instructions describe the local reviewed candidate, not necessarily the public main branch. The associated candidate changes are not published as an identified final release. The exact candidate code and weight access must be supplied and tested on the presentation host before these instructions are relied upon. The public main branch does not contain docs/RUN_SERVICE.md. No public hosted service is claimed.

# Run the reviewed Phase 2 service

The service is a local staff-review API. It is not a hosted deployment or an approval/publishing interface. Use the Phase 2 modules, not the Phase 1 modules in the parent directory.

## Restore the release

1. Extract the source ZIP and open `release/code/` as the working directory. These instructions describe that bundled snapshot, not a checkout of public main.
2. Install the recorded original environment with `python -m pip install -r requirements.txt`. Python/CUDA/package compatibility must be checked on the target host. The local review used the separately recorded versions in `report/evidence/current_regression_01nov.json`, not a claim that every original pin was retested.
3. Obtain the three trained weights from the authorised team Drive project and restore them to the paths in `runs/manifest.json`. Model binaries and private photographs are intentionally excluded from the source ZIP. Use the hashes in `tools/preflight_release.py` and `docs/model_card.md`; reject a mismatch.
4. Keep the original Phase 1 split metadata and historical runs unchanged. Never regenerate partitions to run the service.

## Preflight and launch

```sh
export PYTHONPATH=src:.
export SPV_MANIFEST=runs/manifest.json
python tools/preflight_release.py --manifest "$SPV_MANIFEST" --requirements requirements.txt --strict-versions
python -m uvicorn spv.serve:app --host 127.0.0.1 --port 8000 --workers 1
```

The manifest explicitly freezes detector 0.40 / NMS 0.50, segmenter 0.25 / NMS 0.70, matching IoU 0.10, classifier temperature 0.05 / verification 0.90, minimum mask fraction 0.05, and review_mode off. These are historical serving settings. A later team validation sweep selected confidence 0.10, but the historical service used 0.25; do not change the served setting without release testing. Do not substitute the ONNX detector, which has not passed A9b.

## Request and response

```sh
curl http://127.0.0.1:8000/health
curl --fail-with-body -X POST -F 'file=@example.jpg' \
  'http://127.0.0.1:8000/analyze?images=false'
```

Use a non-sensitive photo you are authorised to process. Default `images=true` returns base64 PNG images in addition to JSON; this costs more time and response bandwidth. Coordinates are xyxy pixels after EXIF orientation, RGB input; probabilities are cat then dog; timing units are milliseconds. No ready result permits automatic publication. A human must review both ready and referred outputs in the surrounding workflow.

Expected invalid-input statuses: 400 empty, 415 unreadable, 413 oversized. Invalid model decisions return 503; invalid masks are referred. Encoded limit 15 MiB, decoded limit 25 million pixels. One process serializes shared-model calls. This is not a load-tested multiworker deployment.

## Verify before presentation

```sh
python -m unittest discover -s tests -v
python tools/verify_submission_evidence.py --figures report/figures
```

Restore weights and test `/health`, a valid request with images on and off, and invalid inputs on the actual presentation host. On 4 November the local review completed an actual TCP loopback HTTP smoke test with the fingerprint-matched weights on CPU: health 200, synthetic-image request 200, empty input 400, unreadable input 415; staff approval required and automatic publication disabled. This is not a pet-image quality test, target-host rehearsal, load test, or GPU benchmark. Current-build T4 validation and the clean-runtime live rehearsal remain open. Keep service instructions and authorised weight access working until the final presentation.
